// src/lib.rs

pub mod models;

pub mod prelude {
    pub use super::models::*;
}
